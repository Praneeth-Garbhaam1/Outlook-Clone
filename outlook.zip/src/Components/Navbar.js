import Sidebar from '../sidebar';
import './Navbar.css';
import AppsIcon from '@material-ui/icons/Apps';
import * as React from 'react';
import { ImageLoadState, PrimaryButton } from '@fluentui/react';
import { SearchBox } from '@fluentui/react';
import { Nav, INavLink, INavStyles, INavLinkGroup } from '@fluentui/react';
import { DefaultPalette, Stack, IStackStyles, IStackTokens, IStackItemStyles } from '@fluentui/react';
import { Label, ILabelStyles } from '@fluentui/react';
import { Pivot, PivotItem } from '@fluentui/react';
import { IStyleSet } from '@fluentui/react';
import { Checkbox } from '@fluentui/react';
// const labelStyles = {
//   root: { marginTop: 10 },
// };

// const stackStyles = {
//   root: {
//     background: DefaultPalette.themeTertiary,
//   },
// };
// const stackItemStyles = {
//   root: {
//     alignItems: 'center',
//     background: DefaultPalette.themePrimary,
//     color: DefaultPalette.white,
//     display: 'flex',
//     height: 50,
//     justifyContent: 'center',
//   },
// };

// Tokens definition
// const stackTokens = {
//   childrenGap: 5,
//   padding: 10,
// };
const navLinkGroups = [
  {
    links: [
      {
        name: 'Parent link 1',
        url: 'http://example.com',
        target: '_blank',
        expandAriaLabel: 'Expand Parent link 1',
        collapseAriaLabel: 'Collapse Parent link 1',
        links: [
          {
            name: 'Child link 1',
            url: 'http://example.com',
            target: '_blank',
          },
          {
            name: 'Child link 2',
            url: 'http://example.com',
            target: '_blank',
            expandAriaLabel: 'Expand Child link 2',
            collapseAriaLabel: 'Collapse Child link 2',
            links: [
              {
                name: '3rd level link 1',
                url: 'http://example.com',
                target: '_blank',
              },
              {
                name: '3rd level link 2',
                url: 'http://example.com',
                target: '_blank',
              },
            ],
          },
          {
            name: 'Child link 3',
            url: 'http://example.com',
            target: '_blank',
          },
        ],
      },
      {
        name: 'Parent link 2',
        url: 'http://example.com',
        target: '_blank',
        expandAriaLabel: 'Expand Parent link 2',
        collapseAriaLabel: 'Collapse Parent link 2',
        links: [
          {
            name: 'Child link 4',
            url: 'http://example.com',
            target: '_blank',
          },
        ],
      },
    ],
  },
];
export default function Navbar() {
  return (
    <>
      <div className="header">

        <AppsIcon id="appicon" />

        <p>Outlook</p>
        <div className="search-container">
          <SearchBox placeholder="Search with no animation" id="search"
            onSearch={newValue => console.log('value is ' + newValue)}
            disableAnimation />
        </div>
        <div className="icons">
          <i className="far fa-comments-alt" id="appicon"></i>
          <i className="far fa-sticky-note" id="appicon"></i>
          <i className="far fa-calendar-check" id="appicon"></i>
          <i className="far fa-bell" id="appicon"></i>
          <i className="fas fa-cog" id="appicon"></i>
          <i className="fas fa-question" id="appicon"></i>
          <i className="fas fa-megaphone" id="appicon"></i>
          <button>SP</button>

     
</div>
      </div>
      <div className="secondheader" >
        <div className="icon1">
          <i className="fal fa-bars"></i>
        </div>
        <PrimaryButton text="New Message" allowDisabledFocus id="but" />
        <ul className="secondheaderitems">
          <li><i className="fas fa-trash-alt"></i> Delete</li>
          <li><i className="fal fa-archive"></i> Archive</li>
          <li><i className="fal fa-ban"></i> Junk</li>
          <li><i className="fal fa-broom"></i> Sweep</li>
          <li><i className="fal fa-folders"></i> Move to</li>
          <li><i className="fal fa-tag"></i> Categorize</li>
          <li><i className="fal fa-clock"></i> Snooze</li>
          <li><i className="fal fa-undo"></i> Undo     <i className="fal fa-ellipsis-h"></i></li>
          <li></li>

        </ul>
      </div>
      <Stack horizontal  >

        <Stack.Item >
          <div className="sidebar">
            <Nav ariaLabel="Nav example with nested links" groups={navLinkGroups} />

          </div>
        </Stack.Item>
        <Stack.Item grow={2} >
        <div className="content">
        <Checkbox label="Select All" onChange={_onChange} id="selectall"/>
       
          <Pivot aria-label="Basic Pivot Example" id="pivot">
          
        <span>wsetertf</span>
            <PivotItem
              headerText="Focused"
              headerButtonProps={{
                'data-order': 1,
                'data-title': 'My Files Title',
              }} id="pivot"
            >
              <Label >Pivot #1</Label>
            </PivotItem>
            <PivotItem headerText="Other" id="pivot">
              <Label >Pivot #2</Label>
            </PivotItem>
           <p>oprjer</p>
          </Pivot>
          </div>
        </Stack.Item>
        <Stack.Item grow={3} >
          <div className="mails">
            <img src={'images.png'}/>
            <p id="select">Select an item to read</p>
            <span id="span">Nothing is selected</span>
          </div>
        </Stack.Item>


      </Stack>
              
    </>
  );
  
function _onChange(ev, isChecked) {
  console.log(`The option has been changed to ${isChecked}.`);
}
}